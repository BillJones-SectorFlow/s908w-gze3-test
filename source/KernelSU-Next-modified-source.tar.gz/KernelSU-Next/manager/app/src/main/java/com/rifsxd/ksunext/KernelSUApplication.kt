package com.rifsxd.ksunext

import android.app.Application
import android.system.Os
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import coil.Coil
import coil.ImageLoader
import com.rifsxd.ksunext.ui.util.LocaleHelper
import com.rifsxd.ksunext.ui.util.createRootShellBuilder
import com.rifsxd.ksunext.ui.viewmodel.ModuleViewModel
import com.rifsxd.ksunext.ui.viewmodel.SuperUserViewModel
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import me.zhanghai.android.appiconloader.coil.AppIconFetcher
import me.zhanghai.android.appiconloader.coil.AppIconKeyer
import okhttp3.Cache
import okhttp3.OkHttpClient
import java.io.File
import java.util.*

lateinit var ksuApp: KernelSUApplication

class KernelSUApplication : Application(), ViewModelStoreOwner {

    lateinit var okhttpClient: OkHttpClient
    private val appViewModelStore by lazy { ViewModelStore() }

    override fun onCreate() {
        super.onCreate()
        LocaleHelper.migrateLegacyLocale(this)
        ksuApp = this
        Shell.setDefaultBuilder(createRootShellBuilder(true))
        Shell.enableVerboseLogging = BuildConfig.DEBUG

        val context = this
        val iconSize = resources.getDimensionPixelSize(android.R.dimen.app_icon_size)
        Coil.setImageLoader(
            ImageLoader.Builder(context)
                .components {
                    add(AppIconKeyer())
                    add(AppIconFetcher.Factory(iconSize, false, context))
                }
                .build()
        )

        val webroot = File(dataDir, "webroot")
        if (!webroot.exists()) {
            webroot.mkdir()
        }

        // Provide working env for rust's temp_dir()
        Os.setenv("TMPDIR", cacheDir.absolutePath, true)

        cleanStaleDexFiles(this)

        okhttpClient =
            OkHttpClient.Builder().cache(Cache(File(cacheDir, "okhttp"), 10 * 1024 * 1024))
                .addInterceptor { block ->
                    block.proceed(
                        block.request().newBuilder()
                            .header("User-Agent", "KernelSU-Next/${BuildConfig.VERSION_CODE}")
                            .header("Accept-Language", Locale.getDefault().toLanguageTag()).build()
                    )
                }.build()
    }

    override val viewModelStore: ViewModelStore
        get() = appViewModelStore

    companion object {
        fun cleanStaleDexFiles(context: android.content.Context) {
            runCatching {
                val deContext = runCatching { context.createDeviceProtectedStorageContext() }.getOrNull()
                val targetDirs = listOfNotNull(
                    context.cacheDir,
                    context.codeCacheDir,
                    deContext?.cacheDir,
                    deContext?.codeCacheDir,
                    File("/data/user_de/0/${context.packageName}/cache"),
                    File("/data/user/0/${context.packageName}/cache")
                )
                for (dir in targetDirs) {
                    val mainJar = File(dir, "main.jar")
                    if (mainJar.exists()) {
                        mainJar.setWritable(true, false)
                        runCatching {
                            Os.chmod(mainJar.absolutePath, 420) // 0644 octal = 420 decimal
                        }
                        mainJar.delete()
                    }
                }
            }
        }

        fun ensureDexFilesReadOnly(context: android.content.Context) {
            runCatching {
                val deContext = runCatching { context.createDeviceProtectedStorageContext() }.getOrNull()
                val targetDirs = listOfNotNull(
                    context.cacheDir,
                    context.codeCacheDir,
                    deContext?.cacheDir,
                    deContext?.codeCacheDir,
                    File("/data/user_de/0/${context.packageName}/cache"),
                    File("/data/user/0/${context.packageName}/cache")
                )
                for (dir in targetDirs) {
                    val mainJar = File(dir, "main.jar")
                    if (mainJar.exists()) {
                        mainJar.setReadOnly()
                        runCatching {
                            Os.chmod(mainJar.absolutePath, 292) // 0444 octal = 292
                        }
                    }
                }
            }
        }
    }
}
